package com.example.E_shop.api;

import com.example.E_shop.entity.Order;
import com.example.E_shop.service.OrderService;
import com.example.E_shop.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;
    private final UserService userService;

    public OrderController(OrderService orderService, UserService userService) {
        this.orderService = orderService;
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<String> placeOrder(@AuthenticationPrincipal UserDetails userDetails,
                                             @RequestBody Order order) {
        Optional<Integer> userIdOpt = userService.findByUsername(userDetails.getUsername()).map(u -> u.getId());
        if (userIdOpt.isEmpty()) {
            return ResponseEntity.status(401).body("User not found");
        }
        order.setUserId(userIdOpt.get());
        orderService.placeOrder(order);
        return ResponseEntity.ok("Order placed successfully");
    }


    @GetMapping
    public ResponseEntity<List<Order>> getOrders(@AuthenticationPrincipal UserDetails userDetails) {
        Optional<Integer> userIdOpt = userService.findByUsername(userDetails.getUsername()).map(u -> u.getId());
        if (userIdOpt.isEmpty()) {
            return ResponseEntity.status(401).build();
        }
        List<Order> orders = orderService.findByUserId(userIdOpt.get());
        return ResponseEntity.ok(orders);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable int id) {
        return orderService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
