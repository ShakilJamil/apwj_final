package com.example.E_shop.dto;

import java.util.Map;
import java.util.List;

public class MonthlySalesReportDTO {
    private Map<String, Double> totalSalesPerCategory; // category -> total sales amount
    private double totalRevenue;
    private int numberOfOrders;
    private List<String> bestSellingProducts; // list of product names or IDs

    // getters and setters

    public Map<String, Double> getTotalSalesPerCategory() {
        return totalSalesPerCategory;
    }

    public void setTotalSalesPerCategory(Map<String, Double> totalSalesPerCategory) {
        this.totalSalesPerCategory = totalSalesPerCategory;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public int getNumberOfOrders() {
        return numberOfOrders;
    }

    public void setNumberOfOrders(int numberOfOrders) {
        this.numberOfOrders = numberOfOrders;
    }

    public List<String> getBestSellingProducts() {
        return bestSellingProducts;
    }

    public void setBestSellingProducts(List<String> bestSellingProducts) {
        this.bestSellingProducts = bestSellingProducts;
    }
}