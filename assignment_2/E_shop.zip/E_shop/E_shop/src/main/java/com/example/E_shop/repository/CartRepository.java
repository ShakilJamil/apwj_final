package com.example.E_shop.repository;

import com.example.E_shop.entity.CartItem;

import java.util.List;

public interface CartRepository {
    List<CartItem> findByUserId(int userId);
    void add(CartItem item);
    void updateQuantity(int id, int quantity);
    void remove(int id);
    void clearCart(int userId);
}
