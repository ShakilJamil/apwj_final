package com.example.E_shop.repository;

import com.example.E_shop.entity.Invoice;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class InvoiceRepositoryImpl implements InvoiceRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Invoice> invoiceRowMapper = (rs, rowNum) -> {
        Invoice invoice = new Invoice();
        invoice.setId(rs.getInt("id"));
        invoice.setOrderId(rs.getInt("order_id"));
        invoice.setInvoiceDetails(rs.getString("invoice_details"));
        return invoice;
    };

    public InvoiceRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Optional<Invoice> findById(int id) {
        String sql = "SELECT * FROM invoices WHERE id = ?";
        return jdbcTemplate.query(sql, invoiceRowMapper, id).stream().findFirst();
    }

    @Override
    public Optional<Invoice> findByOrderId(int orderId) {
        String sql = "SELECT * FROM invoices WHERE order_id = ?";
        return jdbcTemplate.query(sql, invoiceRowMapper, orderId).stream().findFirst();
    }

    @Override
    public void save(Invoice invoice) {
        String sql = "INSERT INTO invoices (order_id, invoice_details) VALUES (?, ?)";
        jdbcTemplate.update(sql, invoice.getOrderId(), invoice.getInvoiceDetails());
    }
}
