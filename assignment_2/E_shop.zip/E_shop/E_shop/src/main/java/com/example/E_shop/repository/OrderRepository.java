package com.example.E_shop.repository;

import com.example.E_shop.entity.Order;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface OrderRepository {
    Optional<Order> findById(int id);
    List<Order> findByUserId(int userId);
    void save(Order order);

    Map<String, Double> getTotalSalesPerCategory(int year, int month);
    double getTotalRevenue(int year, int month);
    int getNumberOfOrders(int year, int month);
}
