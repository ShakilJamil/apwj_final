package com.example.E_shop.repository;

import com.example.E_shop.entity.User;

import java.util.Optional;

public interface UserRepository {
    Optional<User> findById(int id);
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    void save(User user);
    void updatePassword(int userId, String newPassword);
    void updateProfile(int id, String username, String email);
    Optional<User> findByResetToken(String token);
    void updateResetToken(int userId, String token, java.time.LocalDateTime expiry);
    void clearResetToken(int userId);

}
