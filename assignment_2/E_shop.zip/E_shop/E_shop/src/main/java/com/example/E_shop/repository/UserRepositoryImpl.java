package com.example.E_shop.repository;

import com.example.E_shop.entity.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public class UserRepositoryImpl implements UserRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<User> userRowMapper = (rs, rowNum) -> {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setRole(rs.getString("role"));
        user.setResetToken(rs.getString("reset_token"));
        Timestamp expiryTimestamp = rs.getTimestamp("reset_token_expiry");
        if (expiryTimestamp != null) {
            user.setResetTokenExpiry(expiryTimestamp.toLocalDateTime());
        } else {
            user.setResetTokenExpiry(null);
        }
        return user;
    };

    public UserRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Optional<User> findById(int id) {
        String sql = "SELECT u.*, r.name AS role " +
                "FROM users u " +
                "JOIN roles r ON u.role_id = r.id " +
                "WHERE u.id = ?";
        return jdbcTemplate.query(sql, userRowMapper, id).stream().findFirst();
    }

    @Override
    public Optional<User> findByUsername(String username) {
        String sql = "SELECT u.*, r.name AS role " +
                "FROM users u " +
                "JOIN roles r ON u.role_id = r.id " +
                "WHERE u.username = ?";
        return jdbcTemplate.query(sql, userRowMapper, username).stream().findFirst();
    }

    @Override
    public Optional<User> findByEmail(String email) {
        String sql = "SELECT u.*, r.name AS role " +
                "FROM users u " +
                "JOIN roles r ON u.role_id = r.id " +
                "WHERE u.email = ?";
        return jdbcTemplate.query(sql, userRowMapper, email).stream().findFirst();
    }

    @Override
    public Optional<User> findByResetToken(String token) {
        String sql = "SELECT u.*, r.name AS role " +
                "FROM users u " +
                "JOIN roles r ON u.role_id = r.id " +
                "WHERE u.reset_token = ?";
        return jdbcTemplate.query(sql, userRowMapper, token).stream().findFirst();
    }

    @Override
    public void save(User user) {
        String roleSql = "SELECT id FROM roles WHERE name = ?";
        Integer roleId;
        try {
            roleId = jdbcTemplate.queryForObject(roleSql, new Object[]{user.getRole()}, Integer.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid role: " + user.getRole());
        }

        String sql = "INSERT INTO users (username, email, password, role_id) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, user.getUsername(), user.getEmail(), user.getPassword(), roleId);
    }

    @Override
    public void updatePassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        jdbcTemplate.update(sql, newPassword, userId);
    }

    @Override
    public void updateProfile(int id, String username, String email) {
        String sql = "UPDATE users SET username = ?, email = ? WHERE id = ?";
        jdbcTemplate.update(sql, username, email, id);
    }

    @Override
    public void clearResetToken(int userId) {
        String sql = "UPDATE users SET reset_token = NULL, reset_token_expiry = NULL WHERE id = ?";
        jdbcTemplate.update(sql, userId);
    }

    @Override
    public void updateResetToken(int userId, String token, LocalDateTime expiry) {
        String sql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?";
        Timestamp expiryTimestamp = expiry != null ? Timestamp.valueOf(expiry) : null;
        jdbcTemplate.update(sql, token, expiryTimestamp, userId);
    }
}
