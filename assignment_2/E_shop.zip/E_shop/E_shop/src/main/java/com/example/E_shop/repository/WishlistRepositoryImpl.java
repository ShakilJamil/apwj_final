package com.example.E_shop.repository;

import com.example.E_shop.entity.WishlistItem;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class WishlistRepositoryImpl implements WishlistRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<WishlistItem> wishlistRowMapper = (rs, rowNum) -> {
        WishlistItem item = new WishlistItem();
        item.setId(rs.getInt("id"));
        item.setUserId(rs.getInt("user_id"));
        item.setProductId(rs.getInt("product_id"));
        return item;
    };

    public WishlistRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<WishlistItem> findByUserId(int userId) {
        String sql = "SELECT * FROM wishlist_items WHERE user_id = ?";
        return jdbcTemplate.query(sql, wishlistRowMapper, userId);
    }

    @Override
    public void add(WishlistItem item) {
        String sql = "INSERT INTO wishlist_items (user_id, product_id) VALUES (?, ?)";
        jdbcTemplate.update(sql, item.getUserId(), item.getProductId());
    }

    @Override
    public void remove(int id) {
        String sql = "DELETE FROM wishlist_items WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }
}
