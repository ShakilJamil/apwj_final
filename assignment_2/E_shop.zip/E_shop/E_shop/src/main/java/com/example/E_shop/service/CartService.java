package com.example.E_shop.service;

import com.example.E_shop.entity.CartItem;

import java.util.List;

public interface CartService {
    List<CartItem> getCartByUserId(int userId);
    void addToCart(CartItem item);
    void updateCartItemQuantity(int cartItemId, int quantity);
    void removeFromCart(int cartItemId);
    void clearCart(int userId);
}
