package com.example.E_shop.service;

import com.example.E_shop.entity.Invoice;

import java.util.Optional;

public interface InvoiceService {
    Optional<Invoice> findById(int id);
    Optional<Invoice> findByOrderId(int orderId);
    void generateInvoice(Invoice invoice);
}
