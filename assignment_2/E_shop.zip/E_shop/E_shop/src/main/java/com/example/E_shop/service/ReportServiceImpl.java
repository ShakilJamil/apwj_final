package com.example.E_shop.service;

import com.example.E_shop.dto.MonthlySalesReportDTO;
import com.example.E_shop.repository.OrderRepository;
import com.example.E_shop.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ReportServiceImpl implements ReportService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public ReportServiceImpl(OrderRepository orderRepository,
                             ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    @Override
    public MonthlySalesReportDTO generateMonthlySalesReport(int year, int month) {
        MonthlySalesReportDTO report = new MonthlySalesReportDTO();

        Map<String, Double> salesPerCategory = orderRepository.getTotalSalesPerCategory(year, month);
        double totalRevenue = orderRepository.getTotalRevenue(year, month);
        int numberOfOrders = orderRepository.getNumberOfOrders(year, month);
        List<String> bestSellingProducts = productRepository.getBestSellingProducts(year, month);

        report.setTotalSalesPerCategory(salesPerCategory);
        report.setTotalRevenue(totalRevenue);
        report.setNumberOfOrders(numberOfOrders);
        report.setBestSellingProducts(bestSellingProducts);

        return report;
    }
}
