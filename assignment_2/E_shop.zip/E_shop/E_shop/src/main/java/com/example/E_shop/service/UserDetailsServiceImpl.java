package com.example.E_shop.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final JdbcTemplate jdbcTemplate;

    public UserDetailsServiceImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String sql = "SELECT u.id, u.username, u.password, r.name as role " +
                "FROM users u JOIN roles r ON u.role_id = r.id WHERE u.username = ?";

        return jdbcTemplate.query(sql, new Object[]{username}, rs -> {
            if (rs.next()) {
                String uname = rs.getString("username");
                String pwd = rs.getString("password");
                String role = rs.getString("role");

                return User.builder()
                        .username(uname)
                        .password(pwd)
                        .roles(role)
                        .build();
            } else {
                throw new UsernameNotFoundException("User not found with username: " + username);
            }
        });
    }
}
