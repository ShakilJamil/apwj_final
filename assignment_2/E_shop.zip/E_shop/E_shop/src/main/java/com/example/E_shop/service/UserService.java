package com.example.E_shop.service;

import com.example.E_shop.entity.User;

import java.util.Optional;

public interface UserService {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    void registerUser(User user);
    void updatePassword(int userId, String newPassword);
    Optional<User> findById(int id);
    Optional<User> findByResetToken(String token);
    void updateResetToken(int userId, String token, java.time.LocalDateTime expiry);
    void clearResetToken(int userId);
    void sendForgotPasswordEmail(String toEmail, String resetLink);
}
