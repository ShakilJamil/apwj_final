package com.example.E_shop.service;

import com.example.E_shop.entity.WishlistItem;
import com.example.E_shop.repository.WishlistRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WishlistServiceImpl implements WishlistService {

    private final WishlistRepository wishlistRepository;

    public WishlistServiceImpl(WishlistRepository wishlistRepository) {
        this.wishlistRepository = wishlistRepository;
    }

    @Override
    public List<WishlistItem> getWishlistByUserId(int userId) {
        return wishlistRepository.findByUserId(userId);
    }

    @Override
    public void addToWishlist(WishlistItem item) {
        wishlistRepository.add(item);
    }

    @Override
    public void removeFromWishlist(int id) {
        wishlistRepository.remove(id);
    }
}