const API_BASE = "http://localhost:8081/api";
let jwtToken = null;

// Helpers
function showMessage(msg) {
  alert(msg);
}

// Register
async function register() {
  const username = document.getElementById("reg-username").value;
  const email = document.getElementById("reg-email").value;
  const password = document.getElementById("reg-password").value;

  const response = await fetch(`${API_BASE}/users/register`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({username, email, password})
  });
  const text = await response.text();
  if (response.ok) {
    showMessage("Registered successfully! Please login.");
  } else {
    showMessage(text);
  }
}

// Login
async function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  const response = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({username, password})
  });
  if (!response.ok) {
    showMessage("Login failed: Invalid credentials");
    return;
  }
  const data = await response.json();
  jwtToken = data.token;
  showMessage("Login successful!");
  afterLogin();
}

// After login UI adjustments
function afterLogin() {
  document.getElementById("auth-section").style.display = "none";
  document.getElementById("profile-section").style.display = "block";
  document.getElementById("products-section").style.display = "block";
  fetchProfile();
  fetchProducts();
}

// Logout
function logout() {
  jwtToken = null;
  document.getElementById("auth-section").style.display = "block";
  document.getElementById("profile-section").style.display = "none";
  document.getElementById("products-section").style.display = "none";
  showMessage("Logged out");
}

// Fetch profile
async function fetchProfile() {
  const response = await fetch(`${API_BASE}/users/profile`, {
    headers: {Authorization: `Bearer ${jwtToken}`}
  });
  if (response.ok) {
    const user = await response.json();
    document.getElementById("profile-info").textContent = JSON.stringify(user, null, 2);
  } else {
    document.getElementById("profile-info").textContent = "Failed to load profile.";
  }
}

// Change password
async function changePassword() {
  const newPassword = document.getElementById("change-password-input").value;
  const response = await fetch(`${API_BASE}/users/change-password`, {
    method: "PUT",
    headers: {
      "Authorization": `Bearer ${jwtToken}`,
      "Content-Type": "text/plain"
    },
    body: newPassword
  });
  const text = await response.text();
  showMessage(text);
}

// Forgot password
async function forgotPassword() {
  const email = document.getElementById("forgot-email").value;
  const response = await fetch(`${API_BASE}/users/forgot-password?email=${encodeURIComponent(email)}`, {
    method: "POST"
  });
  const text = await response.text();
  showMessage(text);
}

// Reset password
async function resetPassword() {
  const token = document.getElementById("reset-token").value;
  const newPassword = document.getElementById("reset-new-password").value;
  const response = await fetch(`${API_BASE}/users/reset-password?token=${encodeURIComponent(token)}`, {
    method: "PUT",
    headers: {"Content-Type": "text/plain"},
    body: newPassword
  });
  const text = await response.text();
  showMessage(text);
}

// Fetch products
async function fetchProducts() {
  const response = await fetch(`${API_BASE}/products`, {
    headers: {Authorization: `Bearer ${jwtToken}`}
  });
  if (!response.ok) {
    showMessage("Failed to load products");
    return;
  }
  const products = await response.json();
  const list = document.getElementById("product-list");
  list.innerHTML = "";
  products.forEach(p => {
    const li = document.createElement("li");
    li.textContent = `${p.name} - $${p.price} - Category: ${p.category} - Discount: ${p.discount || 0}%`;
    list.appendChild(li);
  });
}

// Add product (Admin only)
async function addProduct() {
  const name = document.getElementById("prod-name").value;
  const category = document.getElementById("prod-category").value;
  const price = Number(document.getElementById("prod-price").value);
  const expiry = document.getElementById("prod-expiry").value;
  const discount = Number(document.getElementById("prod-discount").value);

  const response = await fetch(`${API_BASE}/products`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${jwtToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({name, category, price, expiryDate: expiry, discount})
  });

  const text = await response.text();
  showMessage(text);
  fetchProducts();
}
