package com.example.E_shop.api;

import com.example.E_shop.entity.Invoice;
import com.example.E_shop.service.InvoiceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
@CrossOrigin
@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }


    @GetMapping("/{id}")
    public ResponseEntity<Invoice> getInvoiceById(@PathVariable int id) {
        Optional<Invoice> invoiceOpt = invoiceService.findById(id);
        return invoiceOpt.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Get invoice by order id
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Invoice> getInvoiceByOrderId(@PathVariable int orderId) {
        Optional<Invoice> invoiceOpt = invoiceService.findByOrderId(orderId);
        return invoiceOpt.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
