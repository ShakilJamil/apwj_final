package com.example.E_shop.api;

import com.example.E_shop.entity.User;
import com.example.E_shop.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
@CrossOrigin
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final JavaMailSender mailSender;

    public UserController(UserService userService,
                          PasswordEncoder passwordEncoder,JavaMailSender mailSender) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
        this.mailSender = mailSender;


    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        Optional<User> existingUser = userService.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }
        user.setRole("USER");
        userService.registerUser(user);
        return ResponseEntity.ok("User registered successfully");
    }


    @GetMapping("/profile")
    public ResponseEntity<User> getProfile(Principal principal) {
        Optional<User> userOpt = userService.findByUsername(principal.getName());
        return userOpt.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    @PreAuthorize("hasRole('USER')")
    @PutMapping("/change-password")
    public ResponseEntity<String> changePassword(Principal principal, @RequestBody String newPassword) {
        Optional<User> userOpt = userService.findByUsername(principal.getName());
        if (userOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        userService.updatePassword(userOpt.get().getId(), newPassword);
        return ResponseEntity.ok("Password updated successfully");
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
        Optional<User> userOpt = userService.findByEmail(email);
        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User with this email does not exist");
        }

        String token = UUID.randomUUID().toString();
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(15);
        userService.updateResetToken(userOpt.get().getId(), token, expiry);

        String resetLink = "http://localhost:8080/api/users/reset-password?token=" + token;
        userService.sendForgotPasswordEmail(email, resetLink);

        return ResponseEntity.ok("Reset link sent to your email");
    }

    @PutMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestParam String token, @RequestBody String newPassword) {
        Optional<User> userOpt = userService.findByResetToken(token);
        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid or expired token");
        }

        User user = userOpt.get();
        if (user.getResetTokenExpiry() == null || user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest().body("Token has expired");
        }

        userService.updatePassword(user.getId(), newPassword);
        userService.clearResetToken(user.getId());

        return ResponseEntity.ok("Password reset successfully");
    }
}
