package com.example.E_shop.api;

import com.example.E_shop.entity.WishlistItem;
import com.example.E_shop.service.UserService;
import com.example.E_shop.service.WishlistService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/wishlist")
public class WishlistController {

    private final WishlistService wishlistService;
    private final UserService userService;  // add this

    public WishlistController(WishlistService wishlistService, UserService userService) {
        this.wishlistService = wishlistService;
        this.userService = userService;  // inject here
    }

    @GetMapping
    public ResponseEntity<List<WishlistItem>> getWishlist(@AuthenticationPrincipal UserDetails userDetails) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        List<WishlistItem> items = wishlistService.getWishlistByUserId(userId);
        return ResponseEntity.ok(items);
    }

    @PostMapping
    public ResponseEntity<String> addToWishlist(@AuthenticationPrincipal UserDetails userDetails,
                                                @RequestBody WishlistItem item) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        item.setUserId(userId);
        wishlistService.addToWishlist(item);
        return ResponseEntity.ok("Item added to wishlist");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> removeFromWishlist(@AuthenticationPrincipal UserDetails userDetails,
                                                     @PathVariable int id) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        wishlistService.removeFromWishlist(id);
        return ResponseEntity.ok("Item removed from wishlist");
    }
}
