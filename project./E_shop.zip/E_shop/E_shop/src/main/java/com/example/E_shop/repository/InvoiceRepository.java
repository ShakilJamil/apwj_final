package com.example.E_shop.repository;

import com.example.E_shop.entity.Invoice;

import java.util.Optional;

public interface InvoiceRepository {
    Optional<Invoice> findById(int id);
    Optional<Invoice> findByOrderId(int orderId);
    void save(Invoice invoice);
}
