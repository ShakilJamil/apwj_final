package com.example.E_shop.repository;

import com.example.E_shop.entity.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class OrderRepositoryImpl implements OrderRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Order> orderRowMapper = (rs, rowNum) -> {
        Order order = new Order();
        order.setId(rs.getInt("id"));
        order.setUserId(rs.getInt("user_id"));
        order.setOrderDate(rs.getDate("order_date"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        return order;
    };

    public OrderRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Optional<Order> findById(int id) {
        String sql = "SELECT * FROM orders WHERE id = ?";
        return jdbcTemplate.query(sql, orderRowMapper, id).stream().findFirst();
    }

    @Override
    public List<Order> findByUserId(int userId) {
        String sql = "SELECT * FROM orders WHERE user_id = ?";
        return jdbcTemplate.query(sql, orderRowMapper, userId);
    }

    @Override
    public void save(Order order) {
        String sql = "INSERT INTO orders (user_id, order_date, total_amount) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, order.getUserId(), new Date(order.getOrderDate().getTime()), order.getTotalAmount());
    }
@Override
    public Map<String, Double> getTotalSalesPerCategory(int year, int month) {
        String sql = "SELECT p.category, SUM(oi.quantity * oi.price) AS total_sales " +
                "FROM orders o " +
                "JOIN order_items oi ON o.id = oi.order_id " +
                "JOIN products p ON oi.product_id = p.id " +
                "WHERE YEAR(o.order_date) = ? AND MONTH(o.order_date) = ? " +
                "GROUP BY p.category";

        return jdbcTemplate.query(sql, new Object[]{year, month},
                rs -> {
                    Map<String, Double> map = new java.util.HashMap<>();
                    while (rs.next()) {
                        map.put(rs.getString("category"), rs.getDouble("total_sales"));
                    }
                    return map;
                });
    }
@Override
    public double getTotalRevenue(int year, int month) {
        String sql = "SELECT SUM(oi.quantity * oi.price) AS total_revenue " +
                "FROM orders o " +
                "JOIN order_items oi ON o.id = oi.order_id " +
                "WHERE YEAR(o.order_date) = ? AND MONTH(o.order_date) = ?";

        Double total = jdbcTemplate.queryForObject(sql, new Object[]{year, month}, Double.class);
        return total == null ? 0.0 : total;
    }
@Override
    public int getNumberOfOrders(int year, int month) {
        String sql = "SELECT COUNT(*) FROM orders " +
                "WHERE YEAR(order_date) = ? AND MONTH(order_date) = ?";

        Integer count = jdbcTemplate.queryForObject(sql, new Object[]{year, month}, Integer.class);
        return count == null ? 0 : count;
    }
}
