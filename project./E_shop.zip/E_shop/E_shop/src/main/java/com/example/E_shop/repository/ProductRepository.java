package com.example.E_shop.repository;

import com.example.E_shop.entity.Product;

import java.util.List;
import java.util.Optional;

public interface ProductRepository {
    Optional<Product> findById(int id);
    List<Product> findAll();
    List<Product> findByCategory(String category);
    List<Product> findExpiringWithinDays(int days);
    List<Product> findExpired();
    void save(Product product);
    void update(Product product);
    void deleteById(int id);
    List<String> getBestSellingProducts(int year, int month);
}
