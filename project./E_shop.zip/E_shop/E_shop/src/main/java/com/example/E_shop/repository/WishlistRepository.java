package com.example.E_shop.repository;

import com.example.E_shop.entity.WishlistItem;

import java.util.List;

public interface WishlistRepository {
    List<WishlistItem> findByUserId(int userId);
    void add(WishlistItem item);
    void remove(int id);
}
