package com.example.E_shop.service;

import com.example.E_shop.entity.CartItem;
import com.example.E_shop.repository.CartRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;

    public CartServiceImpl(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    @Override
    public List<CartItem> getCartByUserId(int userId) {
        return cartRepository.findByUserId(userId);
    }

    @Override
    public void addToCart(CartItem item) {
        cartRepository.add(item);
    }

    @Override
    public void updateCartItemQuantity(int cartItemId, int quantity) {
        cartRepository.updateQuantity(cartItemId, quantity);
    }

    @Override
    public void removeFromCart(int cartItemId) {
        cartRepository.remove(cartItemId);
    }

    @Override
    public void clearCart(int userId) {
        cartRepository.clearCart(userId);
    }
}
