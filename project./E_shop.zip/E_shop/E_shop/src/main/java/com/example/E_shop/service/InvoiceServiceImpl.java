package com.example.E_shop.service;

import com.example.E_shop.entity.Invoice;
import com.example.E_shop.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public InvoiceServiceImpl(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public Optional<Invoice> findById(int id) {
        return invoiceRepository.findById(id);
    }

    @Override
    public Optional<Invoice> findByOrderId(int orderId) {
        return invoiceRepository.findByOrderId(orderId);
    }

    @Override
    public void generateInvoice(Invoice invoice) {
        invoiceRepository.save(invoice);
    }
}
