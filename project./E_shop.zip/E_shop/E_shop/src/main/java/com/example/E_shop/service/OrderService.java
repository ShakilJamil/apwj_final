package com.example.E_shop.service;

import com.example.E_shop.entity.Order;

import java.util.List;
import java.util.Optional;

public interface OrderService {
    Optional<Order> findById(int id);
    List<Order> findByUserId(int userId);
    void placeOrder(Order order);
}
