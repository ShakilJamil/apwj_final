package com.example.E_shop.service;


import com.example.E_shop.dto.MonthlySalesReportDTO;

public interface ReportService {
    MonthlySalesReportDTO generateMonthlySalesReport(int year, int month);
}
