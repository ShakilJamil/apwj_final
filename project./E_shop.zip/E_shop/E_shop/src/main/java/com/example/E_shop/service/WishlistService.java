package com.example.E_shop.service;

import com.example.E_shop.entity.WishlistItem;

import java.util.List;

public interface WishlistService {
    List<WishlistItem> getWishlistByUserId(int userId);
    void addToWishlist(WishlistItem item);
    void removeFromWishlist(int id);
}
